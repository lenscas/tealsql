---@meta

local tealsql = {}
---@param Param1 string
---@return Pool
function tealsql.connect_pool(Param1) end
---@param Param1 boolean
---@return string
function tealsql.gen_json(Param1) end
---@generic Res
---@param Param1 string
---@param Param2 fun(Param1:Connection):Res
---@return Res
function tealsql.connect(Param1,Param2) end
---@return any
function tealsql.nul() end
---@param Param1 integer
---@param Param2 integer
---@param Param3 integer
---@return Interval
function tealsql.interval(Param1,Param2,Param3) end
---@param Param1 string
---@return string
function tealsql.help(Param1) end
---@param Param1 string
---@return any
function tealsql.__index(Param1) end
---@class Pool
local Pool = {}
---@param Param1 string
---@return string
function Pool.help(Param1) end
---@generic Res
---@param self Pool
---@param Param2 fun(Param1:Connection):Res
---@return Res
function Pool.get_connection(self,Param2) end
---@class Connection
local Connection = {}
---@param Param1 string
---@return string
function Connection.help(Param1) end
---@param self Connection
---@param Param2 string
---@param Param3 { [integer]: ( boolean|integer|number|{ [any]: any}|string )}
---@return { [string]: ( boolean|integer|number|{ [any]: any}|string )}
function Connection.fetch_optional(self,Param2,Param3) end
---@param self Connection
---@param Param2 string
---@param Param3 { [integer]: ( boolean|integer|number|{ [any]: any}|string )}
---@return ({ [string]: ( boolean|integer|number|{ [any]: any}|string )})[]
function Connection.fetch_all(self,Param2,Param3) end
---@param self Connection
---@param Param2 string
---@param Param3 { [integer]: ( boolean|integer|number|{ [any]: any}|string )}
---@param Param4 integer
---@return Stream
function Connection.fetch_all_async(self,Param2,Param3,Param4) end
---@param self Connection
---@param Param2 string
---@param Param3 { [integer]: ( boolean|integer|number|{ [any]: any}|string )}
---@return integer
function Connection.execute(self,Param2,Param3) end
---@param self Connection
---@param Param2 string
---@param Param3 { [integer]: ( boolean|integer|number|{ [any]: any}|string )}
---@return { [string]: ( boolean|integer|number|{ [any]: any}|string )}
function Connection.fetch_one(self,Param2,Param3) end
---@param self Connection
---@param Param2 string
---@param Param3 { [string]: ( boolean|integer|number|{ [any]: any}|string )}
---@param Param4 boolean
---@return integer
function Connection.insert(self,Param2,Param3,Param4) end
---@param self Connection
---@param Param2 string
---@param Param3 (string)[]
---@param Param4 ((( boolean|integer|number|{ [any]: any}|string ))[])[]
---@param Param5 boolean
---@return integer
function Connection.bulk_insert(self,Param2,Param3,Param4,Param5) end
---@param self Connection
---@param Param2 string
---@param Param3 { [string]: ( boolean|integer|number|{ [any]: any}|string )}
---@param Param4 { [string]: ( boolean|integer|number|{ [any]: any}|string )}
---@param Param5 boolean
---@return integer
function Connection.update(self,Param2,Param3,Param4,Param5) end
---@param self Connection
---@param name string
---@param values { [string]: ( boolean|integer|number|{ [any]: any}|string )}
---@param index string
---@param to_replace { [string]: ( boolean|integer|number|{ [any]: any}|string )}
---@param needs_to_get_quoted boolean
---@return integer
function Connection.upsert(self,name,values,index,to_replace,needs_to_get_quoted) end
---@param self Connection
---@param Param2 string
---@param Param3 { [string]: ( boolean|integer|number|{ [any]: any}|string )}
---@param Param4 boolean
---@return integer
function Connection.delete(self,Param2,Param3,Param4) end
---@generic Res
---@param self Connection
---@param Param2 fun(Param1:Connection):boolean,Res
---@return boolean
---@return Res
function Connection.begin(self,Param2) end
---@class Stream
local Stream = {}
---@param Param1 Stream
---@return fun(Param1:Stream):any
---@return Stream
function Stream.iter(Param1) end
---@param Param1 string
---@return string
function Stream.help(Param1) end
---@param self Stream
---@return boolean
---@return any
function Stream.try_next(self) end
---@param self Stream
---@return any
function Stream.next(self) end
---@generic X
---@param self Stream
---@param Param2 fun(Param1:any):X
---@return (X)[]
function Stream.loop_all(self,Param2) end
---@class Interval
---@field months integer
---@field days integer
---@field microseconds integer
local Interval = {}

 return tealsql
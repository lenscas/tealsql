---@meta

local tealsql = {}
---@type any The value used to represent `null` values in json.
tealsql.null = nil
---@param Param1 string
---@return Pool
function tealsql.connect_pool(Param1) end
---@param Param1 boolean
---@return string
function tealsql.gen_json(Param1) end
---@generic Res
---@param Param1 string
---@param Param2 fun(Param1:Connection):Res ...
---@return Res ...
function tealsql.connect(Param1,Param2) end
---@return any
function tealsql.nul() end
---@param Param1 integer
---@param Param2 integer
---@param Param3 integer
---@return Interval
function tealsql.interval(Param1,Param2,Param3) end
---@param Param1 string
---@return string
function tealsql.help(Param1) end
---@class Pool:userdata
local Pool = {}
---@param Param1 string
---@return string
function Pool.help(Param1) end
---@generic Res
---@param self Pool
---@param Param2 fun(Param1:Connection):Res ...
---@return Res ...
function Pool.get_connection(self,Param2) end
---@class Connection
local Connection = {}
---@param Param1 string
---@return string
function Connection.help(Param1) end
---@param self Connection
---@param query string
---@param params (any)[]
---@return { [string]: any}
function Connection.fetch_optional(self,query,params) end
---@param self Connection
---@param query string
---@param params (any)[]
---@return ({ [string]: any})[]
function Connection.fetch_all(self,query,params) end
---@param self Connection
---@param query string
---@param params (any)[]
---@param chunk_count integer
---@return Stream
function Connection.fetch_all_async(self,query,params,chunk_count) end
---@param self Connection
---@param query string
---@param params (any)[]
---@return integer
function Connection.execute(self,query,params) end
---@param self Connection
---@param query string
---@param params (any)[]
---@return { [string]: any}
function Connection.fetch_one(self,query,params) end
---@param self Connection
---@param name string
---@param values { [string]: any}
---@param needs_to_get_quoted boolean
---@return integer
function Connection.insert(self,name,values,needs_to_get_quoted) end
---@param self Connection
---@param name string
---@param columns (string)[]
---@param values ((any)[])[]
---@param needs_to_get_quoted boolean
---@return integer
function Connection.bulk_insert(self,name,columns,values,needs_to_get_quoted) end
---@param self Connection
---@param name string
---@param old_values { [string]: any}
---@param new_values { [string]: any}
---@param needs_to_get_quoted boolean
---@return integer
function Connection.update(self,name,old_values,new_values,needs_to_get_quoted) end
---@param self Connection
---@param name string
---@param values { [string]: any}
---@param index string
---@param to_replace { [string]: any}
---@param needs_to_get_quoted boolean
---@return integer
function Connection.upsert(self,name,values,index,to_replace,needs_to_get_quoted) end
---@param self Connection
---@param name string
---@param check_on { [string]: any}
---@param needs_to_get_quoted boolean
---@return integer
function Connection.delete(self,name,check_on,needs_to_get_quoted) end
---@generic Res
---@param self Connection
---@param Param2 fun(Param1:Connection):boolean,Res ...
---@return boolean
---@return Res ...
function Connection.begin(self,Param2) end
---@diagnostic disable-next-line: duplicate-doc-alias
---@alias Res any Temporary workaround for lls not having support for generic classes
---@class Stream:userdata
local Stream = {}
---@param Param1 string
---@return string
function Stream.help(Param1) end
---@generic Res
---@param self Stream
---@return fun(Param1:Stream):Res
---@return Stream
function Stream.iter(self) end
---@generic Res
---@param self Stream
---@return boolean
---@return Res
function Stream.try_next(self) end
---@generic Res
---@param self Stream
---@return Res
function Stream.next(self) end
---@generic Out
---@generic Res
---@param self Stream
---@param Param2 fun(Param1:Res):Out
---@return (Out)[]
function Stream.loop_all(self,Param2) end
---@class Interval
---@field months integer
---@field days integer
---@field microseconds integer
local Interval = {}

 return tealsql